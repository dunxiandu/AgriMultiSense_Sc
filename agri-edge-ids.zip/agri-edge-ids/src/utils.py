"""General utilities: config loading, reproducibility, timing."""
from __future__ import annotations

import os
import random
import time
from contextlib import contextmanager
from typing import Any, Dict

import numpy as np
import torch
import yaml


def load_config(path: str) -> Dict[str, Any]:
    """Load a YAML configuration file into a nested dict."""
    with open(path, "r", encoding="utf-8") as f:
        cfg = yaml.safe_load(f)
    return cfg


def set_seed(seed: int) -> None:
    """Seed python, numpy and torch RNGs for reproducibility."""
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    torch.cuda.manual_seed_all(seed)


def get_device() -> torch.device:
    if torch.cuda.is_available():
        return torch.device("cuda")
    if torch.backends.mps.is_available():  # Apple Silicon
        return torch.device("mps")
    return torch.device("cpu")


@contextmanager
def timer(label: str = "block"):
    """Context manager returning elapsed wall-clock time in milliseconds.

    Usage:
        with timer("inference") as t:
            ...
        print(t.elapsed_ms)
    """

    class _T:
        elapsed_ms: float = 0.0

    handle = _T()
    start = time.perf_counter()
    try:
        yield handle
    finally:
        handle.elapsed_ms = (time.perf_counter() - start) * 1000.0


def ensure_dir(path: str) -> str:
    os.makedirs(path, exist_ok=True)
    return path


def count_parameters(model: torch.nn.Module) -> int:
    return sum(p.numel() for p in model.parameters() if p.requires_grad)
