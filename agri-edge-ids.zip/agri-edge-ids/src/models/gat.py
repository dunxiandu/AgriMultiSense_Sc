"""Heterogeneous Graph Attention Mechanism (Sec. 3.4.3) and masked attention
for asynchronous / missing modalities (Sec. 3.4.4).

For node i and neighbor j in N(i):

    e_ij^t = LeakyReLU( a^T [ W h_i^t | W h_j^t ] )
    alpha_ij^t = softmax_j( e_ij^t * omega_ij^t )              # edge-aware weighting
    alpha_ij^t <- alpha_ij^t * m_j^t / sum_j(alpha_ij^t * m_j^t)  # masked attention (Eq. 3.4.4)
    h_i^{t,l+1} = sigma( sum_j alpha_ij^t W h_j^t )

Implemented with a dense (N x N) attention formulation, which is simple,
numerically transparent, and adequate for the moderate per-event graph
sizes (tens of nodes) produced by a single 10-second multimodal event
window (Sec. 4.1.1). For very large graphs, replace with a sparse
scatter-softmax implementation (e.g. via torch_geometric) using the same
edge_index / omega_ij / mask semantics.
"""
from __future__ import annotations

import torch
import torch.nn as nn
import torch.nn.functional as F


def _dense_adjacency(edge_index: torch.Tensor, edge_weight: torch.Tensor, n: int) -> torch.Tensor:
    """Builds an (N, N) dense matrix containing omega_ij at [i, j], 0 elsewhere."""
    adj = torch.zeros(n, n, device=edge_index.device if edge_index.numel() else edge_weight.device)
    if edge_index.numel() == 0:
        return adj
    src, dst = edge_index[0], edge_index[1]
    adj[src, dst] = edge_weight
    return adj


class HeteroGATLayer(nn.Module):
    """A single multi-head heterogeneous graph attention layer.

    `W` is shared across modalities/node types as stated in Sec. 3.4.3
    ("a learnable linear transformation that is consistent across
    modalities"); modality-specific information is instead carried in the
    node embeddings produced upstream by the visual/IoT encoders.
    """

    def __init__(self, in_dim: int, out_dim: int, heads: int = 4, dropout: float = 0.3):
        super().__init__()
        assert out_dim % heads == 0, "out_dim must be divisible by heads"
        self.heads = heads
        self.head_dim = out_dim // heads
        self.out_dim = out_dim

        self.W = nn.Linear(in_dim, out_dim, bias=False)
        self.attn = nn.Parameter(torch.empty(heads, 2 * self.head_dim))
        nn.init.xavier_uniform_(self.attn)
        self.leaky_relu = nn.LeakyReLU(0.2)
        self.dropout = nn.Dropout(dropout)

    def forward(
        self,
        x: torch.Tensor,
        edge_index: torch.Tensor,
        edge_weight: torch.Tensor,
        availability: torch.Tensor,
    ) -> torch.Tensor:
        """
        Args:
            x: (N, in_dim) node features.
            edge_index: (2, E) src/dst indices.
            edge_weight: (E,) omega_ij composite spatio-temporal-reliability weight.
            availability: (N,) validity mask m_j in {0, 1} for masked attention.

        Returns:
            (N, out_dim) updated node representations, post nonlinearity.
        """
        n = x.shape[0]
        device = x.device
        if n == 0:
            return torch.zeros(0, self.out_dim, device=device)

        h = self.W(x)  # (N, out_dim)
        h_heads = h.view(n, self.heads, self.head_dim)  # (N, H, hd)

        omega = _dense_adjacency(edge_index, edge_weight, n)  # (N, N)
        adj_mask = (omega > 0).float()  # structural adjacency (1 where an edge exists)

        # raw attention logits e_ij per head: a^T [Wh_i | Wh_j]
        h_i = h_heads.unsqueeze(1).expand(n, n, self.heads, self.head_dim)  # (N, N, H, hd) -> h_i repeated over j
        h_j = h_heads.unsqueeze(0).expand(n, n, self.heads, self.head_dim)  # h_j repeated over i
        concat = torch.cat([h_i, h_j], dim=-1)  # (N, N, H, 2*hd)
        e = self.leaky_relu(torch.einsum("ijhd,hd->ijh", concat, self.attn))  # (N, N, H)

        # edge-aware weighting: multiply logits' exponent input by omega_ij (Sec 3.4.2/3.4.3)
        e = e * omega.unsqueeze(-1)

        # mask out non-edges with -inf before softmax
        neg_inf = torch.finfo(e.dtype).min
        e = e.masked_fill(adj_mask.unsqueeze(-1) == 0, neg_inf)

        alpha = F.softmax(e, dim=1)  # softmax over neighbors j, per head

        # masked attention for missing/unavailable target nodes (Sec. 3.4.4):
        # alpha_ij <- alpha_ij * m_j / sum_j(alpha_ij * m_j)
        m_j = availability.view(1, n, 1)  # broadcast over i and heads
        alpha = alpha * m_j
        denom = alpha.sum(dim=1, keepdim=True).clamp(min=1e-8)
        alpha = alpha / denom
        alpha = self.dropout(alpha)

        # aggregate: h_i' = sum_j alpha_ij * h_j
        out = torch.einsum("ijh,jhd->ihd", alpha, h_heads)  # (N, H, hd)
        out = out.reshape(n, self.out_dim)
        return F.elu(out)


class HeteroGAT(nn.Module):
    """Stacks `num_layers` HeteroGATLayer blocks (L=2 in Table 3)."""

    def __init__(self, in_dim: int, hidden_dim: int = 128, num_layers: int = 2, heads: int = 4, dropout: float = 0.3):
        super().__init__()
        layers = []
        d_in = in_dim
        for _ in range(num_layers):
            layers.append(HeteroGATLayer(d_in, hidden_dim, heads=heads, dropout=dropout))
            d_in = hidden_dim
        self.layers = nn.ModuleList(layers)

    def forward(self, x, edge_index, edge_weight, availability):
        h = x
        for layer in self.layers:
            h = layer(h, edge_index, edge_weight, availability)
        return h
