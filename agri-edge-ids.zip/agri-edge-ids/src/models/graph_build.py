"""Graph construction: node assembly and edge weighting (Sec. 3.4.1 - 3.4.2).

Given the outputs of the visual encoder and the IoT sensor encoder for a
single event window, this module builds the heterogeneous graph
G_t = (V_t, E_t) with V_t = V_visual U V_sensor U V_environment, connects
each node to its k spatio-temporally nearest neighbors, and computes the
composite edge weight

    omega_ij^t = exp(-d_ij / sigma) * exp(-|delta_t_ij| / tau) * r_j^t

where d_ij is spatial distance, delta_t_ij is temporal misalignment, and
r_j^t is the reliability of the *target* node j (Sec. 3.4.2).
"""
from __future__ import annotations

from dataclasses import dataclass
from typing import Optional

import torch


@dataclass
class HeteroGraph:
    """A single heterogeneous multimodal event graph."""

    x: torch.Tensor              # (N, F) node features, already projected to F
    node_type: torch.Tensor      # (N,) long tensor: 0=visual, 1=sensor, 2=env
    positions: torch.Tensor      # (N, 2) spatial coordinates (meters)
    timestamps: torch.Tensor     # (N,) seconds within the event window
    reliability: torch.Tensor    # (N,) per-node reliability r_i in [0, 1]
    availability: torch.Tensor   # (N,) validity mask m_i in {0, 1}
    edge_index: torch.Tensor     # (2, E) source, target node indices
    edge_weight: torch.Tensor    # (E,) omega_ij composite weight


def knn_spatiotemporal_edges(
    positions: torch.Tensor,
    timestamps: torch.Tensor,
    reliability: torch.Tensor,
    k: int = 5,
    spatial_sigma: float = 25.0,
    temporal_tau: float = 2.0,
) -> tuple[torch.Tensor, torch.Tensor]:
    """Builds a k-NN graph over combined spatio-temporal proximity and
    returns (edge_index, edge_weight) following the omega_ij definition in
    Sec. 3.4.2.

    Nodes without meaningful spatial coordinates (e.g. global environment
    nodes) should be given a shared/placeholder position; the exponential
    decay simply saturates to 1.0 at zero distance.
    """
    n = positions.shape[0]
    device = positions.device
    if n == 0:
        return torch.zeros(2, 0, dtype=torch.long, device=device), torch.zeros(0, device=device)

    dist = torch.cdist(positions, positions)  # (N, N) spatial distance d_ij
    dt = (timestamps.unsqueeze(0) - timestamps.unsqueeze(1)).abs()  # (N, N) |delta_t|

    src_list, dst_list, w_list = [], [], []

    k_eff = min(k, n - 1)
    if k_eff > 0:
        # exclude self before top-k
        dist_no_self = dist.clone()
        dist_no_self.fill_diagonal_(float("inf"))
        _, nn_idx = torch.topk(dist_no_self, k_eff, dim=1, largest=False)  # (N, k)

        for i in range(n):
            for j in nn_idx[i].tolist():
                d_ij = dist[i, j]
                dt_ij = dt[i, j]
                r_j = reliability[j]
                w = torch.exp(-d_ij / spatial_sigma) * torch.exp(-dt_ij / temporal_tau) * r_j
                src_list.append(i)
                dst_list.append(j)
                w_list.append(w)

    # Always add a self-loop for every node (weight = its own reliability).
    # This guarantees every node has at least one valid neighbor even when
    # it has no spatio-temporal neighbors (e.g. a single-node graph, or an
    # isolated environment node), avoiding an all -inf softmax row in the
    # attention layer.
    for i in range(n):
        src_list.append(i)
        dst_list.append(i)
        # Clamp away from exactly zero so a node whose own reliability has
        # collapsed to 0 (e.g. a currently-unavailable sensor) still keeps
        # a numerically valid self-loop and never yields an all-masked
        # attention row.
        w_list.append(reliability[i].clamp(min=1e-3))

    edge_index = torch.tensor([src_list, dst_list], dtype=torch.long, device=device)
    edge_weight = torch.stack(w_list) if w_list else torch.zeros(0, device=device)
    return edge_index, edge_weight


def assemble_graph(
    visual_z: torch.Tensor,
    visual_positions: torch.Tensor,
    visual_timestamps: torch.Tensor,
    visual_reliability: torch.Tensor,
    sensor_s: torch.Tensor,
    sensor_positions: torch.Tensor,
    sensor_timestamps: torch.Tensor,
    sensor_reliability: torch.Tensor,
    sensor_availability: torch.Tensor,
    env_embedding: Optional[torch.Tensor],
    env_position: torch.Tensor,
    k_neighbors: int = 5,
    spatial_sigma: float = 25.0,
    temporal_tau: float = 2.0,
) -> HeteroGraph:
    """Concatenates visual, sensor, and (optional) environment nodes into a
    single HeteroGraph and builds spatio-temporal edges, per Sec. 3.4.1.

    All per-node-type feature tensors must already be projected to the same
    dimensionality F by the caller (see models/model.py) before concatenation.
    """
    device = visual_z.device
    n_v = visual_z.shape[0]
    n_s = sensor_s.shape[0]
    n_e = 1 if env_embedding is not None else 0

    feats, types, positions, timestamps, reliability, availability = [], [], [], [], [], []

    if n_v > 0:
        feats.append(visual_z)
        types.append(torch.zeros(n_v, dtype=torch.long, device=device))
        positions.append(visual_positions)
        timestamps.append(visual_timestamps)
        reliability.append(visual_reliability)
        availability.append(torch.ones(n_v, device=device))

    if n_s > 0:
        feats.append(sensor_s)
        types.append(torch.ones(n_s, dtype=torch.long, device=device))
        positions.append(sensor_positions)
        timestamps.append(sensor_timestamps)
        reliability.append(sensor_reliability)
        availability.append(sensor_availability)

    if n_e > 0:
        feats.append(env_embedding.unsqueeze(0))
        types.append(torch.full((1,), 2, dtype=torch.long, device=device))
        positions.append(env_position.unsqueeze(0))
        timestamps.append(torch.zeros(1, device=device))
        reliability.append(torch.ones(1, device=device))
        availability.append(torch.ones(1, device=device))

    if not feats:
        raise ValueError("Cannot assemble an empty graph: no nodes of any type were provided.")

    x = torch.cat(feats, dim=0)
    node_type = torch.cat(types, dim=0)
    positions_t = torch.cat(positions, dim=0)
    timestamps_t = torch.cat(timestamps, dim=0)
    reliability_t = torch.cat(reliability, dim=0)
    availability_t = torch.cat(availability, dim=0)

    edge_index, edge_weight = knn_spatiotemporal_edges(
        positions_t, timestamps_t, reliability_t, k_neighbors, spatial_sigma, temporal_tau
    )

    return HeteroGraph(
        x=x,
        node_type=node_type,
        positions=positions_t,
        timestamps=timestamps_t,
        reliability=reliability_t,
        availability=availability_t,
        edge_index=edge_index,
        edge_weight=edge_weight,
    )
