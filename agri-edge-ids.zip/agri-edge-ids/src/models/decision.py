"""Intrusion Decision and Alert Generation (manuscript Sec. 3.5).

  f_t     = GELU(W_f G_hat_t + b_f)                  latent intrusion feature
  p_t     = sigmoid(W_p f_t + b_p)                   immediate confidence
  lambda_t= sigmoid(W_g [p_t | p_{t-1}])              stabilization gate
  p_hat_t = lambda_t * p_t + (1 - lambda_t) * p_hat_{t-1}   stabilized confidence
  u_t     = 1 - mean_i(r_i^t)                         uncertainty score
  s_t     = p_hat_t * (1 - u_t)                       final decision score
  theta_t = theta_0 + eta * u_t                       adaptive alert threshold
  a_t     = 1[s_t > theta_t]                          instantaneous alert
  C_t     = (1/W) sum_{tau=t-W+1}^{t} a_tau            temporal consistency score
  alarm transmitted iff C_t >= rho
"""
from __future__ import annotations

from collections import deque
from typing import Optional

import torch
import torch.nn as nn


class IntrusionDecisionHead(nn.Module):
    """Maps the fused graph representation to an immediate intrusion
    confidence score p_t, and exposes the trainable latent projection used
    during training (BCE / focal loss operates on the raw logit).
    """

    def __init__(self, in_dim: int = 128, hidden_dim: int = 128):
        super().__init__()
        self.proj = nn.Linear(in_dim, hidden_dim)
        self.act = nn.GELU()
        self.classifier = nn.Linear(hidden_dim, 1)

    def forward(self, g_hat: torch.Tensor) -> torch.Tensor:
        """g_hat: (..., in_dim) -> logit: (..., 1) (pre-sigmoid, for loss fns)"""
        f = self.act(self.proj(g_hat))
        return self.classifier(f)


class TemporalConfidenceStabilizer(nn.Module):
    """lambda_t = sigmoid(W_g [p_t | p_{t-1}])
    p_hat_t = lambda_t * p_t + (1 - lambda_t) * p_hat_{t-1}
    """

    def __init__(self):
        super().__init__()
        self.gate = nn.Linear(2, 1)

    def forward(self, p_t: torch.Tensor, p_hat_prev: Optional[torch.Tensor]) -> torch.Tensor:
        if p_hat_prev is None:
            p_hat_prev = torch.zeros_like(p_t)
        lam = torch.sigmoid(self.gate(torch.stack([p_t, p_hat_prev], dim=-1)))
        return (lam.squeeze(-1) * p_t + (1 - lam.squeeze(-1)) * p_hat_prev)


class AdaptiveAlertGenerator:
    """Stateful, inference-time alert logic (Sec. 3.5): uncertainty-aware
    thresholding plus multi-window temporal consistency validation.

    This class is intentionally *not* an nn.Module: it holds no learnable
    parameters and maintains simple scalar/queue state across an event
    stream, mirroring an edge-deployment alerting service.
    """

    def __init__(
        self,
        base_threshold: float = 0.5,
        uncertainty_sensitivity: float = 0.25,
        consistency_window: int = 5,
        consistency_ratio: float = 0.6,
    ):
        self.theta_0 = base_threshold
        self.eta = uncertainty_sensitivity
        self.window = consistency_window
        self.rho = consistency_ratio
        self._history: deque = deque(maxlen=consistency_window)

    def reset(self) -> None:
        self._history.clear()

    def step(self, p_hat_t: float, mean_reliability: float) -> dict:
        """Consumes one event window's stabilized confidence and mean node
        reliability; returns the decision score, adaptive threshold,
        instantaneous alert flag, temporal consistency score, and whether
        an alarm should actually be transmitted.
        """
        u_t = 1.0 - mean_reliability
        s_t = p_hat_t * (1.0 - u_t)
        theta_t = self.theta_0 + self.eta * u_t
        a_t = 1.0 if s_t > theta_t else 0.0

        self._history.append(a_t)
        c_t = sum(self._history) / len(self._history)
        alarm_transmitted = c_t >= self.rho

        return {
            "uncertainty": u_t,
            "decision_score": s_t,
            "adaptive_threshold": theta_t,
            "instantaneous_alert": bool(a_t),
            "temporal_consistency": c_t,
            "alarm_transmitted": bool(alarm_transmitted),
        }
