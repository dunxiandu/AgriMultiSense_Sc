"""Reliability-Aware Edge Visual Perception Module (manuscript Sec. 3.2).

Pipeline per Figure 2:
  1. Visibility assessment  v_t = Vis(I_t)                     (Eq. visibility)
  2. Lightweight ROI proposal on an edge-oriented backbone       (Eq. ROI)
  3. Reliability-aware embedding e_i = phi(x_i) (*) r_i          (Eq. embedding)
  4. Reliability coefficient r_i = sigmoid(w^T [c_i, l_i, o_i, b_i]) (Eq. r_i)
  5. Uncertainty score u_i = 1 - r_i
  6. Final region representation z_i = [e_i, p_i, c_i]
  7. Gate: only propagate z_i with r_i >= reliability_threshold

The backbone is MobileNetV3-Small (Table 3), chosen for its accuracy /
compute trade-off on resource constrained edge hardware (e.g. Jetson Nano).
"""
from __future__ import annotations

from dataclasses import dataclass
from typing import List

import torch
import torch.nn as nn
import torchvision


@dataclass
class ROIObservation:
    """A single detected region of interest at time t."""

    patch: torch.Tensor          # (C, H, W) cropped & resized patch
    bbox_norm: torch.Tensor      # (4,) normalized [cx, cy, w, h] in [0, 1]
    detector_confidence: float   # c_i in [0, 1]
    illumination_consistency: float  # l_i in [0, 1], 1 = well lit / stable
    occlusion_ratio: float       # o_i in [0, 1], 0 = unoccluded
    blur_intensity: float        # b_i in [0, 1], 0 = sharp


class VisibilityAssessor(nn.Module):
    """Estimates a scalar frame-level visibility reliability score v_t.

    A tiny CNN head regresses visibility degradation directly from the raw
    frame (fog / rain / low-light / motion-blur cues) without requiring
    ground-truth weather labels, following the reliability-aware design
    philosophy of Sec. 3.2.
    """

    def __init__(self, in_channels: int = 3):
        super().__init__()
        self.net = nn.Sequential(
            nn.Conv2d(in_channels, 16, 3, stride=2, padding=1),
            nn.BatchNorm2d(16),
            nn.ReLU(inplace=True),
            nn.Conv2d(16, 32, 3, stride=2, padding=1),
            nn.BatchNorm2d(32),
            nn.ReLU(inplace=True),
            nn.AdaptiveAvgPool2d(1),
        )
        self.head = nn.Linear(32, 1)

    def forward(self, image: torch.Tensor) -> torch.Tensor:
        """image: (B, C, H, W) -> v_t in (0, 1), shape (B,)"""
        feat = self.net(image).flatten(1)
        return torch.sigmoid(self.head(feat)).squeeze(-1)


class ReliabilityAwareVisualEncoder(nn.Module):
    """Encodes a batch of ROI crops into reliability-modulated embeddings.

    Implements Eqs. for e_i, r_i, u_i and z_i from Sec. 3.2, plus the
    threshold gate that suppresses unreliable observations before they
    reach the multimodal graph.
    """

    def __init__(
        self,
        embedding_dim: int = 128,
        reliability_threshold: float = 0.35,
        pretrained: bool = True,
    ):
        super().__init__()
        self.reliability_threshold = reliability_threshold
        self.embedding_dim = embedding_dim

        backbone = torchvision.models.mobilenet_v3_small(
            weights=torchvision.models.MobileNet_V3_Small_Weights.DEFAULT
            if pretrained
            else None
        )
        # Strip the classification head; keep the convolutional feature extractor.
        self.backbone = backbone.features
        self.pool = nn.AdaptiveAvgPool2d(1)
        backbone_out_dim = 576  # MobileNetV3-Small final feature channels
        self.project = nn.Linear(backbone_out_dim, embedding_dim)

        # Reliability coefficient r_i = sigmoid(w^T [c_i, l_i, o_i, b_i])
        self.reliability_mlp = nn.Sequential(
            nn.Linear(4, 16),
            nn.ReLU(inplace=True),
            nn.Linear(16, 1),
        )

        self.visibility = VisibilityAssessor()

    def encode_patches(self, patches: torch.Tensor) -> torch.Tensor:
        """patches: (N, C, H, W) -> phi(x_i): (N, embedding_dim)"""
        feat = self.backbone(patches)
        feat = self.pool(feat).flatten(1)
        return self.project(feat)

    def forward(self, frame: torch.Tensor, rois: List[ROIObservation]):
        """
        Args:
            frame: (C, H, W) full frame for visibility assessment.
            rois: list of ROIObservation extracted from `frame`.

        Returns:
            dict with:
              'z': (M, embedding_dim + 4 + 1) kept region-level representations
                    [e_i (modulated), bbox_norm (4), detector_confidence (1)]
              'reliability': (M,) reliability scores of kept regions
              'uncertainty': (M,) uncertainty scores of kept regions
              'frame_visibility': scalar visibility score v_t
              'num_kept': number of ROIs surviving the reliability gate
        """
        device = frame.device
        v_t = self.visibility(frame.unsqueeze(0)).squeeze(0)

        if len(rois) == 0:
            empty = torch.zeros(0, self.embedding_dim + 4 + 1, device=device)
            return {
                "z": empty,
                "reliability": torch.zeros(0, device=device),
                "uncertainty": torch.zeros(0, device=device),
                "frame_visibility": v_t,
                "num_kept": 0,
            }

        patches = torch.stack([r.patch for r in rois]).to(device)
        e_raw = self.encode_patches(patches)  # (N, D)

        quality = torch.tensor(
            [
                [r.detector_confidence, r.illumination_consistency, r.occlusion_ratio, r.blur_intensity]
                for r in rois
            ],
            dtype=torch.float32,
            device=device,
        )
        r_i = torch.sigmoid(self.reliability_mlp(quality)).squeeze(-1)  # (N,)
        u_i = 1.0 - r_i

        e_mod = e_raw * r_i.unsqueeze(-1)  # element-wise modulation

        bbox = torch.stack([r.bbox_norm for r in rois]).to(device)  # (N, 4)
        conf = torch.tensor([r.detector_confidence for r in rois], device=device).unsqueeze(-1)

        z_all = torch.cat([e_mod, bbox, conf], dim=-1)  # (N, D+4+1)

        keep_mask = r_i >= self.reliability_threshold
        z = z_all[keep_mask]
        r_kept = r_i[keep_mask]
        u_kept = u_i[keep_mask]

        return {
            "z": z,
            "reliability": r_kept,
            "uncertainty": u_kept,
            "frame_visibility": v_t,
            "num_kept": int(keep_mask.sum().item()),
        }
