"""End-to-end Edge-AI Spatio-Temporal Heterogeneous Graph Attention model.

Wires together every component described in Sec. 3 of the manuscript:

  frame + ROIs        -> ReliabilityAwareVisualEncoder   (Sec. 3.2)
  IoT observations     -> IoTSensorEncoder                (Sec. 3.3)
  visual + IoT + env   -> assemble_graph                  (Sec. 3.4.1-3.4.2)
  graph                -> HeteroGAT                        (Sec. 3.4.3-3.4.4)
  node states          -> HierarchicalReliabilityReadout   (Sec. 3.4.5)
  graph representation -> IntrusionDecisionHead +
                           TemporalConfidenceStabilizer     (Sec. 3.5)

`AgriEdgeIDS.forward_event` processes exactly one 10-second multimodal
event window and threads temporal state (`graph_memory`, `p_hat_prev`)
through to the next call, matching the streaming/edge-deployment setting
described in the paper. `forward_sequence` is a convenience wrapper for
training on a whole ordered sequence of event windows at once.
"""
from __future__ import annotations

from dataclasses import dataclass
from typing import List, Optional

import torch
import torch.nn as nn

from src.models.decision import IntrusionDecisionHead, TemporalConfidenceStabilizer
from src.models.gat import HeteroGAT
from src.models.graph_build import assemble_graph
from src.models.iot import IoTSensorEncoder, SensorObservation
from src.models.readout import HierarchicalReliabilityReadout
from src.models.visual import ROIObservation, ReliabilityAwareVisualEncoder


class EnvironmentEncoder(nn.Module):
    """Encodes scene-level environmental context (Sec. 3.1, 3.4.5) --
    temperature, humidity, rainfall, wind, illumination, fog density -- into
    a fixed-size embedding e_ctx used both as an environment graph node and
    for the final context-adaptive fusion step.
    """

    def __init__(self, input_dim: int = 6, embedding_dim: int = 128):
        super().__init__()
        self.net = nn.Sequential(
            nn.Linear(input_dim, embedding_dim),
            nn.ReLU(inplace=True),
            nn.Linear(embedding_dim, embedding_dim),
        )

    def forward(self, env_features: torch.Tensor) -> torch.Tensor:
        return self.net(env_features)


@dataclass
class EventWindow:
    """All raw multimodal inputs synchronized within one 10-second event
    window (Sec. 4.1.1), as consumed by `AgriEdgeIDS.forward_event`.
    """

    frame: torch.Tensor                     # (C, H, W)
    rois: List[ROIObservation]
    sensor_observations: List[SensorObservation]
    env_features: torch.Tensor              # (env_input_dim,)
    env_position: torch.Tensor              # (2,) nominal environment-node coordinates
    window_time: float                      # seconds, used to timestamp graph nodes
    label: Optional[int] = None             # 1 = intrusion, 0 = normal (if available)


@dataclass
class ModelState:
    """Streaming state threaded across consecutive event windows."""

    graph_memory: Optional[torch.Tensor] = None
    p_hat_prev: Optional[torch.Tensor] = None


class AgriEdgeIDS(nn.Module):
    def __init__(
        self,
        embedding_dim: int = 128,
        gat_layers: int = 2,
        attention_heads: int = 4,
        dropout: float = 0.3,
        reliability_threshold: float = 0.35,
        env_input_dim: int = 6,
        modality_input_dims: dict | None = None,
        temporal_decay: dict | None = None,
        k_neighbors: int = 5,
        spatial_sigma: float = 25.0,
        temporal_tau: float = 2.0,
        pretrained_visual_backbone: bool = True,
    ):
        super().__init__()
        self.embedding_dim = embedding_dim
        self.k_neighbors = k_neighbors
        self.spatial_sigma = spatial_sigma
        self.temporal_tau = temporal_tau

        self.visual_encoder = ReliabilityAwareVisualEncoder(
            embedding_dim=embedding_dim,
            reliability_threshold=reliability_threshold,
            pretrained=pretrained_visual_backbone,
        )
        # visual node z has dim (embedding_dim + 4 bbox + 1 conf); project to embedding_dim
        self.visual_node_proj = nn.Linear(embedding_dim + 4 + 1, embedding_dim)

        self.iot_encoder = IoTSensorEncoder(
            embedding_dim=embedding_dim,
            modality_input_dims=modality_input_dims,
            temporal_decay=temporal_decay,
        )
        # sensor node s_hat has dim (embedding_dim + 2); project to embedding_dim
        self.sensor_node_proj = nn.Linear(embedding_dim + 2, embedding_dim)

        self.env_encoder = EnvironmentEncoder(env_input_dim, embedding_dim)

        self.gat = HeteroGAT(
            in_dim=embedding_dim,
            hidden_dim=embedding_dim,
            num_layers=gat_layers,
            heads=attention_heads,
            dropout=dropout,
        )

        self.readout = HierarchicalReliabilityReadout(
            hidden_dim=embedding_dim, context_dim=embedding_dim
        )

        self.decision_head = IntrusionDecisionHead(in_dim=embedding_dim, hidden_dim=embedding_dim)
        self.stabilizer = TemporalConfidenceStabilizer()

    def forward_event(self, event: EventWindow, state: ModelState) -> dict:
        """Processes a single event window. Mutates and returns `state` so
        the caller can thread it into the next call (streaming inference),
        or discard it for i.i.d.-style training on shuffled windows.
        """
        device = next(self.parameters()).device
        frame = event.frame.to(device)
        env_features = event.env_features.to(device)
        env_position = event.env_position.to(device)

        # --- 3.2 Visual perception ---
        vis_out = self.visual_encoder(frame, event.rois)
        visual_z_raw = vis_out["z"]  # (Mv, D+5)
        n_v = visual_z_raw.shape[0]
        visual_z = self.visual_node_proj(visual_z_raw) if n_v > 0 else torch.zeros(0, self.embedding_dim, device=device)
        visual_positions = torch.stack([r.bbox_norm[:2] * 100.0 for r in event.rois]).to(device) if n_v > 0 else torch.zeros(0, 2, device=device)
        visual_timestamps = torch.full((n_v,), event.window_time, device=device)
        visual_reliability = vis_out["reliability"]

        # --- 3.3 IoT sensor modeling ---
        iot_out = self.iot_encoder(event.sensor_observations, event.window_time, device)
        sensor_s_raw = iot_out["s_hat"]
        n_s = sensor_s_raw.shape[0]
        sensor_s = self.sensor_node_proj(sensor_s_raw) if n_s > 0 else torch.zeros(0, self.embedding_dim, device=device)
        sensor_positions = iot_out["positions"]
        sensor_timestamps = torch.full((n_s,), event.window_time, device=device)
        sensor_reliability = iot_out["reliability"]
        sensor_availability = iot_out["availability"]

        # --- environmental context node/embedding ---
        env_embedding = self.env_encoder(env_features.unsqueeze(0)).squeeze(0)

        # --- 3.4.1-3.4.2 Graph assembly ---
        graph = assemble_graph(
            visual_z=visual_z,
            visual_positions=visual_positions,
            visual_timestamps=visual_timestamps,
            visual_reliability=visual_reliability,
            sensor_s=sensor_s,
            sensor_positions=sensor_positions,
            sensor_timestamps=sensor_timestamps,
            sensor_reliability=sensor_reliability,
            sensor_availability=sensor_availability,
            env_embedding=env_embedding,
            env_position=env_position,
            k_neighbors=self.k_neighbors,
            spatial_sigma=self.spatial_sigma,
            temporal_tau=self.temporal_tau,
        )

        # --- 3.4.3-3.4.4 Heterogeneous graph attention ---
        h = self.gat(graph.x, graph.edge_index, graph.edge_weight, graph.availability)

        # --- 3.4.5 Hierarchical reliability-aware temporal readout ---
        g_hat, new_memory = self.readout(
            h, graph.node_type, graph.reliability, env_embedding, state.graph_memory
        )

        # --- 3.5 Intrusion decision & temporal confidence stabilization ---
        logit = self.decision_head(g_hat.unsqueeze(0)).squeeze()
        p_t = torch.sigmoid(logit)
        p_hat_t = self.stabilizer(p_t.unsqueeze(0), state.p_hat_prev.unsqueeze(0) if state.p_hat_prev is not None else None).squeeze(0)

        state.graph_memory = new_memory.detach()
        state.p_hat_prev = p_hat_t.detach()

        mean_reliability = graph.reliability.mean() if graph.reliability.numel() > 0 else torch.tensor(0.0, device=device)

        return {
            "logit": logit,
            "p_t": p_t,
            "p_hat_t": p_hat_t,
            "mean_reliability": mean_reliability,
            "num_visual_nodes": n_v,
            "num_sensor_nodes": n_s,
            "frame_visibility": vis_out["frame_visibility"],
        }

    def forward_sequence(self, events: List[EventWindow]) -> dict:
        """Runs a full ordered sequence and returns stacked per-window logits
        / stabilized confidences, useful for computing a sequence-level loss
        during training.
        """
        state = ModelState()
        logits, p_hats = [], []
        for event in events:
            out = self.forward_event(event, state)
            logits.append(out["logit"])
            p_hats.append(out["p_hat_t"])
        return {
            "logits": torch.stack(logits),
            "p_hats": torch.stack(p_hats),
        }
