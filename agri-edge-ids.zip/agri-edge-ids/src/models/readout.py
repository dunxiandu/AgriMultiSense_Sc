"""Hierarchical Reliability-Aware Temporal Graph Readout (manuscript Sec. 3.4.5).

Steps, per event window t:
  1. Modality-aware node attention:
       beta_i^t = softmax_i( u^T tanh(W1 h_i^t + W2 m_i^t) )
  2. Reliability-aware graph pooling:
       g_t = sum_i beta_i^t * r_i^t * h_i^t
  3. Temporal graph memory (GRU-style gate):
       z_t = sigmoid(W_z [g_t | g_{t-1}])
       G_t = z_t * g_t + (1 - z_t) * G_{t-1}
  4. Context-adaptive fusion with environmental embedding e_ctx:
       G_hat_t = W_c [G_t | e_ctx] + b_c
"""
from __future__ import annotations

from typing import Optional

import torch
import torch.nn as nn
import torch.nn.functional as F


class ModalityAwareNodeAttention(nn.Module):
    """beta_i^t = softmax_i( u^T tanh(W1 h_i^t + W2 m_i^t) )

    `m_i^t` is a per-node-type embedding (learned lookup by node_type),
    representing the modality context referenced in Sec. 3.4.5.
    """

    def __init__(self, hidden_dim: int, num_node_types: int = 3, attn_dim: int = 64):
        super().__init__()
        self.type_embedding = nn.Embedding(num_node_types, hidden_dim)
        self.W1 = nn.Linear(hidden_dim, attn_dim, bias=False)
        self.W2 = nn.Linear(hidden_dim, attn_dim, bias=False)
        self.u = nn.Linear(attn_dim, 1, bias=False)

    def forward(self, h: torch.Tensor, node_type: torch.Tensor) -> torch.Tensor:
        """h: (N, D), node_type: (N,) -> beta: (N,)"""
        if h.shape[0] == 0:
            return torch.zeros(0, device=h.device)
        m_i = self.type_embedding(node_type)
        score = self.u(torch.tanh(self.W1(h) + self.W2(m_i))).squeeze(-1)  # (N,)
        return F.softmax(score, dim=0)


class TemporalGraphMemory(nn.Module):
    """GRU-style gated memory across successive event windows (Sec. 3.4.5)."""

    def __init__(self, dim: int):
        super().__init__()
        self.gate = nn.Linear(2 * dim, dim)
        self.dim = dim

    def forward(self, g_t: torch.Tensor, g_prev: Optional[torch.Tensor]) -> torch.Tensor:
        if g_prev is None:
            g_prev = torch.zeros_like(g_t)
        z_t = torch.sigmoid(self.gate(torch.cat([g_t, g_prev], dim=-1)))
        return z_t * g_t + (1 - z_t) * g_prev


class ContextAdaptiveFusion(nn.Module):
    """G_hat_t = W_c [G_t | e_ctx] + b_c"""

    def __init__(self, graph_dim: int, context_dim: int, out_dim: int):
        super().__init__()
        self.fc = nn.Linear(graph_dim + context_dim, out_dim)

    def forward(self, g_t: torch.Tensor, e_ctx: torch.Tensor) -> torch.Tensor:
        return self.fc(torch.cat([g_t, e_ctx], dim=-1))


class HierarchicalReliabilityReadout(nn.Module):
    """Combines modality attention, reliability-weighted pooling, temporal
    memory, and context fusion into the final graph-level representation
    G_hat_t used downstream for intrusion decision making (Sec. 3.5).
    """

    def __init__(self, hidden_dim: int = 128, context_dim: int = 128, num_node_types: int = 3):
        super().__init__()
        self.node_attention = ModalityAwareNodeAttention(hidden_dim, num_node_types)
        self.memory = TemporalGraphMemory(hidden_dim)
        self.context_fusion = ContextAdaptiveFusion(hidden_dim, context_dim, hidden_dim)

    def pool(self, h: torch.Tensor, node_type: torch.Tensor, reliability: torch.Tensor) -> torch.Tensor:
        """g_t = sum_i beta_i * r_i * h_i"""
        if h.shape[0] == 0:
            return torch.zeros(h.shape[-1], device=h.device)
        beta = self.node_attention(h, node_type)          # (N,)
        weights = beta * reliability                       # (N,)
        weights = weights / weights.sum().clamp(min=1e-8)
        g_t = (weights.unsqueeze(-1) * h).sum(dim=0)        # (D,)
        return g_t

    def forward(
        self,
        h: torch.Tensor,
        node_type: torch.Tensor,
        reliability: torch.Tensor,
        context_embedding: torch.Tensor,
        prev_memory: Optional[torch.Tensor],
    ):
        """
        Returns:
            g_hat: (out_dim,) final context-fused graph representation G_hat_t
            new_memory: (hidden_dim,) updated temporal graph memory G_t,
                        to be passed as `prev_memory` for the next event window.
        """
        g_t = self.pool(h, node_type, reliability)
        g_mem = self.memory(g_t.unsqueeze(0), prev_memory.unsqueeze(0) if prev_memory is not None else None)
        g_mem = g_mem.squeeze(0)
        g_hat = self.context_fusion(g_mem.unsqueeze(0), context_embedding.unsqueeze(0)).squeeze(0)
        return g_hat, g_mem
