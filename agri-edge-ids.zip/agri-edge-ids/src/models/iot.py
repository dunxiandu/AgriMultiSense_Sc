"""IoT Sensor Modeling and Temporal Representation (manuscript Sec. 3.3).

For each sensor k, at time t:
  h_k^t   = Enc_k(x_k^t; theta_k)                  modality-specific encoding
  Delta_k^t = t - t_k_last                          temporal irregularity
  rel_time_k^t = exp(-kappa_k * Delta_k^t)          temporal reliability decay
  c_k^t   = sigmoid(MLP([quality_k^t]))             sensor confidence estimator
  s_k^t   = [h_k^t | rel_time_k^t | c_k^t]          temporally calibrated repr.
  s_hat_k^t = m_k^t * s_k^t                         validity-aware masking
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Dict, List

import torch
import torch.nn as nn


@dataclass
class SensorObservation:
    """A single IoT sensor reading at time t."""

    sensor_id: str
    modality: str                 # one of the configured modalities, e.g. 'pir'
    value: List[float]            # raw measurement vector (dim depends on modality)
    position_xy: List[float]      # (x, y) location in meters, for spatial edges
    timestamp: float              # seconds
    last_valid_timestamp: float   # timestamp of most recent valid reading
    packet_reliability: float     # in [0, 1]
    signal_stability: float       # in [0, 1]
    missing_event_rate: float     # in [0, 1], higher = more missing events
    is_available: bool = True     # m_k^t


class ModalityEncoder(nn.Module):
    """Small per-modality encoder mapping raw readings into a shared space."""

    def __init__(self, input_dim: int, embedding_dim: int):
        super().__init__()
        self.net = nn.Sequential(
            nn.Linear(input_dim, embedding_dim),
            nn.ReLU(inplace=True),
            nn.Linear(embedding_dim, embedding_dim),
        )

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        return self.net(x)


# Expected raw feature dimensionality per modality. Binary event-driven
# sensors (pir, gate, vibration) use a compact projection; continuous
# sensing modalities (temperature, humidity, illumination, acoustic) use
# short statistical-aggregate vectors (mean/std/min/max style features).
DEFAULT_MODALITY_INPUT_DIMS: Dict[str, int] = {
    "pir": 2,
    "gate": 2,
    "vibration": 4,
    "acoustic": 8,
    "temperature": 4,
    "humidity": 4,
    "illumination": 4,
}


class IoTSensorEncoder(nn.Module):
    """Encodes a heterogeneous batch of sensor observations into calibrated
    node representations s_hat_k^t, as defined in Sec. 3.3.
    """

    def __init__(
        self,
        embedding_dim: int = 128,
        modality_input_dims: Dict[str, int] | None = None,
        temporal_decay: Dict[str, float] | None = None,
    ):
        super().__init__()
        self.embedding_dim = embedding_dim
        modality_input_dims = modality_input_dims or DEFAULT_MODALITY_INPUT_DIMS
        self.temporal_decay = temporal_decay or {m: 0.5 for m in modality_input_dims}

        self.encoders = nn.ModuleDict(
            {m: ModalityEncoder(d, embedding_dim) for m, d in modality_input_dims.items()}
        )
        # sensor confidence estimator c_k^t = sigmoid(MLP([quality indicators]))
        self.confidence_mlp = nn.Sequential(
            nn.Linear(3, 16),
            nn.ReLU(inplace=True),
            nn.Linear(16, 1),
        )

    def forward(self, observations: List[SensorObservation], current_time: float, device):
        """
        Returns dict with:
          's_hat': (K, embedding_dim + 2) calibrated & masked sensor representations
                    [h_k (embedding_dim) | rel_time_k (1) | c_k (1)] * m_k
          'positions': (K, 2) sensor spatial coordinates
          'availability': (K,) validity mask m_k^t
          'reliability': (K,) combined temporal * confidence reliability, used
                          downstream for edge weighting (omega_ij) and readout.
        """
        if len(observations) == 0:
            empty = torch.zeros(0, self.embedding_dim + 2, device=device)
            return {
                "s_hat": empty,
                "positions": torch.zeros(0, 2, device=device),
                "availability": torch.zeros(0, device=device),
                "reliability": torch.zeros(0, device=device),
            }

        h_list, rel_time_list, conf_list, pos_list, avail_list = [], [], [], [], []
        for obs in observations:
            enc = self.encoders.get(obs.modality)
            if enc is None:
                raise KeyError(
                    f"No encoder registered for modality '{obs.modality}'. "
                    f"Known modalities: {list(self.encoders.keys())}"
                )
            x = torch.tensor(obs.value, dtype=torch.float32, device=device).unsqueeze(0)
            h_k = enc(x).squeeze(0)  # (embedding_dim,)

            delta_t = max(0.0, obs.timestamp - obs.last_valid_timestamp)
            kappa_k = self.temporal_decay.get(obs.modality, 0.5)
            rel_time_k = torch.exp(torch.tensor(-kappa_k * delta_t, device=device))

            quality = torch.tensor(
                [obs.packet_reliability, obs.signal_stability, 1.0 - obs.missing_event_rate],
                dtype=torch.float32,
                device=device,
            )
            c_k = torch.sigmoid(self.confidence_mlp(quality.unsqueeze(0))).squeeze()

            h_list.append(h_k)
            rel_time_list.append(rel_time_k)
            conf_list.append(c_k)
            pos_list.append(obs.position_xy)
            avail_list.append(1.0 if obs.is_available else 0.0)

        h = torch.stack(h_list)                                   # (K, D)
        rel_time = torch.stack(rel_time_list).unsqueeze(-1)        # (K, 1)
        conf = torch.stack(conf_list).unsqueeze(-1)                # (K, 1)
        m = torch.tensor(avail_list, device=device).unsqueeze(-1)  # (K, 1)

        s = torch.cat([h, rel_time, conf], dim=-1)  # (K, D+2)
        s_hat = s * m                               # validity-aware masking

        reliability = (rel_time.squeeze(-1) * conf.squeeze(-1)) * m.squeeze(-1)
        positions = torch.tensor(pos_list, dtype=torch.float32, device=device)

        return {
            "s_hat": s_hat,
            "positions": positions,
            "availability": m.squeeze(-1),
            "reliability": reliability,
        }
