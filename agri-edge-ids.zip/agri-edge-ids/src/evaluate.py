#!/usr/bin/env python3
"""Evaluates a trained AgriEdgeIDS checkpoint following the protocol in
Sec. 4.3: Precision, Recall, F1, AUC, per-window inference latency, and
false-alarm rate, aggregated as mean +/- std over multiple random seeds
(re-run this script once per seed and aggregate with `aggregate_runs`
below, or use `--num-seeds` to loop internally on freshly re-initialized
weights when no checkpoint is given, e.g. for a quick sanity check).

Usage:
    python -m src.evaluate --config configs/default.yaml \
        --checkpoint runs/agri_edge_ids_full/seed0/best_model.pt \
        --test-manifest data/synthetic/test.jsonl \
        --image-root data/synthetic
"""
from __future__ import annotations

import argparse
import json
import time
from dataclasses import asdict, dataclass

import numpy as np
import torch
from scipy import stats
from sklearn.metrics import precision_recall_fscore_support, roc_auc_score
from torch.utils.data import DataLoader

from src.data.dataset import AgriEdgeMMIDSequenceDataset, sequence_collate
from src.models.decision import AdaptiveAlertGenerator
from src.models.model import AgriEdgeIDS, ModelState
from src.utils import get_device, load_config


@dataclass
class EvalResult:
    precision: float
    recall: float
    f1: float
    auc: float
    mean_latency_ms: float
    std_latency_ms: float
    false_alarms_per_hour: float
    num_windows: int


@torch.no_grad()
def evaluate_model(model, loader, device, window_sec: float, alert_cfg: dict) -> EvalResult:
    model.eval()
    all_probs, all_labels, latencies = [], [], []
    total_false_alarms, total_hours = 0, 0.0

    for sequences in loader:
        for events in sequences:
            state = ModelState()
            alert_gen = AdaptiveAlertGenerator(**alert_cfg)
            for event in events:
                start = time.perf_counter()
                out = model.forward_event(event, state)
                latencies.append((time.perf_counter() - start) * 1000.0)

                p = float(out["p_hat_t"].item())
                r = float(out["mean_reliability"].item())
                decision = alert_gen.step(p, r)

                if event.label is not None:
                    all_probs.append(p)
                    all_labels.append(int(event.label))
                    if decision["alarm_transmitted"] and event.label == 0:
                        total_false_alarms += 1
                total_hours += window_sec / 3600.0

    if not all_labels:
        raise ValueError("No labeled event windows found in the provided manifest.")

    preds = [1 if p > 0.5 else 0 for p in all_probs]
    precision, recall, f1, _ = precision_recall_fscore_support(
        all_labels, preds, average="binary", zero_division=0
    )
    try:
        auc = roc_auc_score(all_labels, all_probs)
    except ValueError:
        auc = float("nan")  # only one class present in this manifest

    false_alarms_per_hour = total_false_alarms / max(total_hours, 1e-8)

    return EvalResult(
        precision=precision * 100,
        recall=recall * 100,
        f1=f1 * 100,
        auc=auc,
        mean_latency_ms=float(np.mean(latencies)),
        std_latency_ms=float(np.std(latencies)),
        false_alarms_per_hour=false_alarms_per_hour,
        num_windows=len(all_labels),
    )


def paired_ttest(scores_a: list[float], scores_b: list[float], alpha: float = 0.05) -> dict:
    """Paired two-tailed t-test between two methods' per-seed F1 (or other
    metric) scores, matching the significance protocol in Sec. 4.3.
    """
    t_stat, p_value = stats.ttest_rel(scores_a, scores_b)
    return {
        "t_stat": float(t_stat),
        "p_value": float(p_value),
        "significant_at_alpha": bool(p_value < alpha),
    }


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--config", default="configs/default.yaml")
    ap.add_argument("--checkpoint", default=None, help="Path to a trained model .pt file")
    ap.add_argument("--test-manifest", required=True)
    ap.add_argument("--image-root", required=True)
    args = ap.parse_args()

    cfg = load_config(args.config)
    device = get_device()

    test_ds = AgriEdgeMMIDSequenceDataset(args.test_manifest, args.image_root, tuple(cfg["data"]["image_size"]))
    test_loader = DataLoader(test_ds, batch_size=1, shuffle=False, collate_fn=sequence_collate)

    model = AgriEdgeIDS(
        embedding_dim=cfg["model"]["hidden_dim"],
        gat_layers=cfg["model"]["gat_layers"],
        attention_heads=cfg["model"]["attention_heads"],
        dropout=cfg["model"]["dropout"],
        reliability_threshold=cfg["visual"]["reliability_threshold"],
        k_neighbors=cfg["graph"]["k_neighbors"],
        spatial_sigma=cfg["graph"]["spatial_decay_sigma_m"],
        temporal_tau=cfg["graph"]["temporal_decay_tau_s"],
    ).to(device)

    if args.checkpoint:
        model.load_state_dict(torch.load(args.checkpoint, map_location=device))
        print(f"Loaded checkpoint from {args.checkpoint}")
    else:
        print("WARNING: no --checkpoint given; evaluating randomly initialized weights "
              "(useful only to smoke-test the pipeline).")

    alert_cfg = dict(
        base_threshold=cfg["decision"]["alert_base_threshold"],
        uncertainty_sensitivity=cfg["decision"]["uncertainty_sensitivity"],
        consistency_window=cfg["decision"]["temporal_consistency_window"],
        consistency_ratio=cfg["decision"]["temporal_consistency_ratio"],
    )

    result = evaluate_model(model, test_loader, device, cfg["graph"]["temporal_window_s"], alert_cfg)
    print(json.dumps(asdict(result), indent=2))


if __name__ == "__main__":
    main()
