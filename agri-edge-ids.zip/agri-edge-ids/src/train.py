#!/usr/bin/env python3
"""Trains the AgriEdgeIDS model following the protocol in Sec. 4.2 / Table 2:
AdamW, lr=1e-4, weight_decay=1e-5, batch_size=16 sequences, up to 100 epochs,
focal loss, reduce-on-plateau LR schedule, early stopping (patience 10).

Sequences (one per monitoring session / farm-day) are processed one at a
time so the temporal graph memory (Sec. 3.4.5) and confidence stabilizer
(Sec. 3.5) can be threaded through consecutive event windows; gradients
from all windows in a sequence are accumulated before a single optimizer
step, which corresponds to `batch_size` being interpreted at the
event-window level once flattened across sequences of similar length. See
README.md "Notes on batching" for the exact accounting.

Usage:
    python -m src.train --config configs/default.yaml \
        --train-manifest data/synthetic/train.jsonl \
        --val-manifest data/synthetic/val.jsonl \
        --image-root data/synthetic
"""
from __future__ import annotations

import argparse
import os

import torch
from torch.utils.data import DataLoader

from src.data.dataset import AgriEdgeMMIDSequenceDataset, sequence_collate
from src.losses import FocalLoss
from src.models.model import AgriEdgeIDS, ModelState
from src.utils import count_parameters, ensure_dir, get_device, load_config, set_seed


def run_epoch(model, loader, criterion, optimizer, device, train: bool):
    model.train(mode=train)
    total_loss, total_windows = 0.0, 0
    all_probs, all_labels = [], []

    for sequences in loader:
        for events in sequences:
            state = ModelState()
            logits, labels = [], []
            for event in events:
                out = model.forward_event(event, state)
                logits.append(out["logit"])
                if event.label is not None:
                    labels.append(float(event.label))

            if not labels:
                continue

            logits_t = torch.stack(logits).to(device)
            labels_t = torch.tensor(labels, device=device)
            loss = criterion(logits_t, labels_t)

            if train:
                optimizer.zero_grad()
                loss.backward()
                torch.nn.utils.clip_grad_norm_(model.parameters(), max_norm=5.0)
                optimizer.step()

            total_loss += loss.item() * len(labels)
            total_windows += len(labels)
            all_probs.extend(torch.sigmoid(logits_t).detach().cpu().tolist())
            all_labels.extend(labels)

    avg_loss = total_loss / max(1, total_windows)
    return avg_loss, all_probs, all_labels


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--config", default="configs/default.yaml")
    ap.add_argument("--train-manifest", required=True)
    ap.add_argument("--val-manifest", required=True)
    ap.add_argument("--image-root", required=True)
    ap.add_argument("--seed", type=int, default=None)
    ap.add_argument("--epochs", type=int, default=None, help="Override config epochs (useful for quick smoke tests)")
    args = ap.parse_args()

    cfg = load_config(args.config)
    seed = args.seed if args.seed is not None else cfg["experiment"]["seed_list"][0]
    set_seed(seed)
    device = get_device()

    out_dir = ensure_dir(os.path.join(cfg["experiment"]["output_dir"], cfg["experiment"]["name"], f"seed{seed}"))

    train_ds = AgriEdgeMMIDSequenceDataset(
        args.train_manifest, args.image_root, tuple(cfg["data"]["image_size"])
    )
    val_ds = AgriEdgeMMIDSequenceDataset(
        args.val_manifest, args.image_root, tuple(cfg["data"]["image_size"])
    )
    train_loader = DataLoader(train_ds, batch_size=1, shuffle=True, collate_fn=sequence_collate)
    val_loader = DataLoader(val_ds, batch_size=1, shuffle=False, collate_fn=sequence_collate)

    model = AgriEdgeIDS(
        embedding_dim=cfg["model"]["hidden_dim"],
        gat_layers=cfg["model"]["gat_layers"],
        attention_heads=cfg["model"]["attention_heads"],
        dropout=cfg["model"]["dropout"],
        reliability_threshold=cfg["visual"]["reliability_threshold"],
        k_neighbors=cfg["graph"]["k_neighbors"],
        spatial_sigma=cfg["graph"]["spatial_decay_sigma_m"],
        temporal_tau=cfg["graph"]["temporal_decay_tau_s"],
    ).to(device)

    print(f"Model parameters: {count_parameters(model):,}")

    criterion = FocalLoss(
        gamma=cfg["training"]["focal_loss_gamma"], alpha=cfg["training"]["focal_loss_alpha"]
    )
    optimizer = torch.optim.AdamW(
        model.parameters(),
        lr=cfg["training"]["learning_rate"],
        weight_decay=cfg["training"]["weight_decay"],
    )
    scheduler = torch.optim.lr_scheduler.ReduceLROnPlateau(
        optimizer, mode="min", factor=cfg["training"]["lr_reduce_factor"], patience=cfg["training"]["lr_patience"]
    )

    epochs = args.epochs or cfg["training"]["epochs"]
    best_val_loss = float("inf")
    patience_left = cfg["training"]["early_stopping_patience"]
    best_path = os.path.join(out_dir, "best_model.pt")

    for epoch in range(1, epochs + 1):
        train_loss, _, _ = run_epoch(model, train_loader, criterion, optimizer, device, train=True)
        val_loss, val_probs, val_labels = run_epoch(model, val_loader, criterion, optimizer, device, train=False)
        scheduler.step(val_loss)

        print(f"epoch {epoch:03d} | train_loss {train_loss:.4f} | val_loss {val_loss:.4f}")

        if val_loss < best_val_loss - 1e-5:
            best_val_loss = val_loss
            patience_left = cfg["training"]["early_stopping_patience"]
            torch.save(model.state_dict(), best_path)
        else:
            patience_left -= 1
            if patience_left <= 0:
                print(f"Early stopping at epoch {epoch} (no val improvement for "
                      f"{cfg['training']['early_stopping_patience']} epochs).")
                break

    print(f"Best validation loss: {best_val_loss:.4f}. Checkpoint saved to {best_path}")


if __name__ == "__main__":
    main()
