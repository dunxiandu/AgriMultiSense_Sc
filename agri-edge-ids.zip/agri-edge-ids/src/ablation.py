#!/usr/bin/env python3
"""Reproduces the ablation configurations in Table 37 / Table 38:

  Full Model (Edge)      -- everything enabled
  w/o IoT Fusion         -- IoT sensor observations are dropped; the graph
                             is built from visual + environment nodes only
  w/o GAT Layer          -- one fewer heterogeneous GAT layer (L=1 instead
                             of the full model's L=2, Table 3)
  w/o Temporal Window    -- the temporal graph memory (Sec. 3.4.5) and the
                             confidence stabilizer (Sec. 3.5) are reset at
                             every event window instead of being carried
                             across the sequence, removing cross-window
                             temporal context

Each configuration is evaluated with `src/evaluate.evaluate_model`; disable
IoT fusion / limit GAT depth via constructor arguments, and disable
temporal carry-over via the `reset_state_each_window` flag added to a thin
wrapper below (no modification to model.py's streaming API is required).

Usage:
    python -m src.ablation --config configs/default.yaml \
        --test-manifest data/synthetic/test.jsonl --image-root data/synthetic \
        --checkpoint-dir runs/agri_edge_ids_full
"""
from __future__ import annotations

import argparse
import copy
import json
from dataclasses import asdict

import torch
from torch.utils.data import DataLoader

from src.data.dataset import AgriEdgeMMIDSequenceDataset, sequence_collate
from src.evaluate import evaluate_model
from src.models.model import AgriEdgeIDS, EventWindow, ModelState
from src.utils import get_device, load_config


def strip_iot(events: list[EventWindow]) -> list[EventWindow]:
    """w/o IoT Fusion: removes sensor observations from every event window
    so the graph is built from visual + environment nodes only.
    """
    stripped = []
    for e in events:
        e2 = copy.copy(e)
        e2.sensor_observations = []
        stripped.append(e2)
    return stripped


class NoTemporalCarryLoader:
    """Wraps a sequence DataLoader so every event window is evaluated with
    a *fresh* ModelState, i.e. no temporal graph memory or confidence
    stabilization carries across windows (the "w/o Temporal Window"
    ablation). Implemented by splitting each sequence into single-window
    "sequences" before handing off to the shared evaluation loop.
    """

    def __init__(self, loader):
        self.loader = loader

    def __iter__(self):
        for sequences in self.loader:
            for events in sequences:
                for event in events:
                    yield [[event]]  # one sequence per window -> state resets every time


def build_ablation_variants(cfg: dict) -> dict:
    base_kwargs = dict(
        embedding_dim=cfg["model"]["hidden_dim"],
        gat_layers=cfg["model"]["gat_layers"],
        attention_heads=cfg["model"]["attention_heads"],
        dropout=cfg["model"]["dropout"],
        reliability_threshold=cfg["visual"]["reliability_threshold"],
        k_neighbors=cfg["graph"]["k_neighbors"],
        spatial_sigma=cfg["graph"]["spatial_decay_sigma_m"],
        temporal_tau=cfg["graph"]["temporal_decay_tau_s"],
    )

    variants = {
        "Full Model (Edge)": dict(model_kwargs=base_kwargs, strip_iot_fn=None, reset_state=False),
        "w/o IoT Fusion": dict(model_kwargs=base_kwargs, strip_iot_fn=strip_iot, reset_state=False),
        "w/o GAT Layer": dict(
            model_kwargs={**base_kwargs, "gat_layers": max(1, cfg["model"]["gat_layers"] - 1)},
            strip_iot_fn=None,
            reset_state=False,
        ),
        "w/o Temporal Window": dict(model_kwargs=base_kwargs, strip_iot_fn=None, reset_state=True),
    }
    return variants


@torch.no_grad()
def evaluate_variant(model, loader, device, window_sec, alert_cfg, strip_iot_fn, reset_state):
    if reset_state:
        loader = NoTemporalCarryLoader(loader)

    if strip_iot_fn is None:
        return evaluate_model(model, loader, device, window_sec, alert_cfg)

    # Monkey-patch-free approach: wrap the loader to strip IoT observations
    class _StrippedLoader:
        def __iter__(self_inner):
            for sequences in loader:
                yield [strip_iot_fn(events) for events in sequences]

    return evaluate_model(model, _StrippedLoader(), device, window_sec, alert_cfg)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--config", default="configs/default.yaml")
    ap.add_argument("--test-manifest", required=True)
    ap.add_argument("--image-root", required=True)
    ap.add_argument("--checkpoint", default=None, help="Optional shared checkpoint to load into every variant")
    args = ap.parse_args()

    cfg = load_config(args.config)
    device = get_device()

    test_ds = AgriEdgeMMIDSequenceDataset(args.test_manifest, args.image_root, tuple(cfg["data"]["image_size"]))
    alert_cfg = dict(
        base_threshold=cfg["decision"]["alert_base_threshold"],
        uncertainty_sensitivity=cfg["decision"]["uncertainty_sensitivity"],
        consistency_window=cfg["decision"]["temporal_consistency_window"],
        consistency_ratio=cfg["decision"]["temporal_consistency_ratio"],
    )

    variants = build_ablation_variants(cfg)
    results = {}
    for name, spec in variants.items():
        loader = DataLoader(test_ds, batch_size=1, shuffle=False, collate_fn=sequence_collate)
        model = AgriEdgeIDS(**spec["model_kwargs"]).to(device)
        if args.checkpoint:
            # Non-strict load: variant architectures may have fewer GAT layers.
            state_dict = torch.load(args.checkpoint, map_location=device)
            model.load_state_dict(state_dict, strict=False)
        result = evaluate_variant(
            model, loader, device, cfg["graph"]["temporal_window_s"], alert_cfg,
            spec["strip_iot_fn"], spec["reset_state"],
        )
        results[name] = asdict(result)
        print(f"{name}: P={result.precision:.1f} R={result.recall:.1f} F1={result.f1:.1f}")

    print(json.dumps(results, indent=2))


if __name__ == "__main__":
    main()
