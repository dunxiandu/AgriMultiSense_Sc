"""AgriEdge-MMID dataset loader.

The manuscript's AgriEdge-MMID benchmark (built on top of the publicly
released AgriMultiSense sensing dataset, see
https://github.com/dunxiandu/AgriMultiSense/releases/tag/v1.0) combines RGB
+ thermal imagery, acoustic events, environmental telemetry, and LoRaWAN IoT
sensor streams into 10-second, timestamp-synchronized multimodal "event
windows" (Sec. 4.1.1).

Rather than hard-coding assumptions about the exact internal layout of the
released archive (which may be reorganized between dataset versions), this
loader is **manifest-driven**: `scripts/build_manifest.py` walks the raw
downloaded dataset and emits one JSON-Lines manifest file per split
(`train.jsonl`, `val.jsonl`, `test.jsonl`, `field.jsonl`) describing every
event window in the schema documented below. This keeps the modeling code
in `src/models/` fully decoupled from any single raw-dataset directory
layout, and makes it trivial to point the pipeline at a new dataset release
by re-running the manifest builder.

Manifest line schema (one JSON object per line):
{
  "sequence_id": "farm03_2024-11-02",
  "window_time": 1234.0,                # seconds since sequence start
  "image_path": "images/farm03/000123.png",
  "rois": [
    {"bbox_norm": [cx, cy, w, h], "detector_confidence": 0.92,
     "illumination_consistency": 0.8, "occlusion_ratio": 0.1,
     "blur_intensity": 0.05}
  ],
  "sensors": [
    {"sensor_id": "pir_04", "modality": "pir", "value": [1.0, 0.0],
     "position_xy": [12.5, 8.0], "timestamp": 1234.1,
     "last_valid_timestamp": 1230.0, "packet_reliability": 0.98,
     "signal_stability": 0.95, "missing_event_rate": 0.02,
     "is_available": true}
  ],
  "env_features": [24.5, 63.0, 0.0, 1013.2, 3.1, 0.05],  # temp, humidity,
                                                            # rainfall, pressure,
                                                            # wind, fog_density
  "env_position": [50.0, 50.0],
  "label": 1                              # 1 = intrusion, 0 = normal
}

See docs/DATASET_SCHEMA.md for the full field reference and
scripts/build_manifest.py for a reference manifest-generation script.
"""
from __future__ import annotations

import json
import os
from collections import defaultdict
from typing import Dict, List

import torch
import torchvision.transforms.functional as TF
from PIL import Image
from torch.utils.data import Dataset

from src.models.iot import SensorObservation
from src.models.model import EventWindow
from src.models.visual import ROIObservation


def _load_image(image_path: str, image_size: tuple[int, int]) -> torch.Tensor:
    img = Image.open(image_path).convert("RGB")
    img = img.resize(image_size)
    tensor = TF.to_tensor(img)
    return tensor


def _crop_roi(image: torch.Tensor, bbox_norm: List[float], patch_size: int = 64) -> torch.Tensor:
    """Crops and resizes a normalized [cx, cy, w, h] bbox to a fixed patch."""
    _, h, w = image.shape
    cx, cy, bw, bh = bbox_norm
    x1 = max(0, int((cx - bw / 2) * w))
    y1 = max(0, int((cy - bh / 2) * h))
    x2 = min(w, int((cx + bw / 2) * w))
    y2 = min(h, int((cy + bh / 2) * h))
    if x2 <= x1 or y2 <= y1:
        # degenerate box (e.g. clipped at frame edge) -> fall back to full frame
        patch = image
    else:
        patch = image[:, y1:y2, x1:x2]
    patch = TF.resize(patch, [patch_size, patch_size])
    return patch


class AgriEdgeMMIDSequenceDataset(Dataset):
    """Groups manifest entries into ordered per-sequence lists of
    `EventWindow`s, i.e. one item == one continuous monitoring sequence
    (e.g. one day at one farm site), which is the natural unit for
    sequence-level training of the temporal graph memory (Sec. 3.4.5).
    """

    def __init__(self, manifest_path: str, image_root: str, image_size=(640, 640), roi_patch_size: int = 64):
        self.image_root = image_root
        self.image_size = image_size
        self.roi_patch_size = roi_patch_size

        sequences: Dict[str, List[dict]] = defaultdict(list)
        with open(manifest_path, "r", encoding="utf-8") as f:
            for line in f:
                line = line.strip()
                if not line:
                    continue
                entry = json.loads(line)
                sequences[entry["sequence_id"]].append(entry)

        for seq in sequences.values():
            seq.sort(key=lambda e: e["window_time"])

        self.sequence_ids = sorted(sequences.keys())
        self.sequences = sequences

    def __len__(self) -> int:
        return len(self.sequence_ids)

    def _entry_to_event(self, entry: dict) -> EventWindow:
        image_path = os.path.join(self.image_root, entry["image_path"])
        frame = _load_image(image_path, self.image_size)

        rois = []
        for r in entry.get("rois", []):
            bbox = torch.tensor(r["bbox_norm"], dtype=torch.float32)
            patch = _crop_roi(frame, r["bbox_norm"], self.roi_patch_size)
            rois.append(
                ROIObservation(
                    patch=patch,
                    bbox_norm=bbox,
                    detector_confidence=r["detector_confidence"],
                    illumination_consistency=r["illumination_consistency"],
                    occlusion_ratio=r["occlusion_ratio"],
                    blur_intensity=r["blur_intensity"],
                )
            )

        sensors = [
            SensorObservation(
                sensor_id=s["sensor_id"],
                modality=s["modality"],
                value=s["value"],
                position_xy=s["position_xy"],
                timestamp=s["timestamp"],
                last_valid_timestamp=s["last_valid_timestamp"],
                packet_reliability=s["packet_reliability"],
                signal_stability=s["signal_stability"],
                missing_event_rate=s["missing_event_rate"],
                is_available=s.get("is_available", True),
            )
            for s in entry.get("sensors", [])
        ]

        return EventWindow(
            frame=frame,
            rois=rois,
            sensor_observations=sensors,
            env_features=torch.tensor(entry["env_features"], dtype=torch.float32),
            env_position=torch.tensor(entry["env_position"], dtype=torch.float32),
            window_time=entry["window_time"],
            label=entry.get("label"),
        )

    def __getitem__(self, idx: int) -> List[EventWindow]:
        seq_id = self.sequence_ids[idx]
        return [self._entry_to_event(e) for e in self.sequences[seq_id]]


def sequence_collate(batch: List[List[EventWindow]]) -> List[List[EventWindow]]:
    """Sequences have variable length and variable per-window graph size,
    so we keep the batch as a plain Python list of sequences rather than
    collating into a single tensor. `src/train.py` loops over sequences
    (and, within each, over event windows) explicitly.
    """
    return batch
