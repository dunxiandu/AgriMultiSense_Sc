#!/usr/bin/env bash
# Downloads the AgriMultiSense v1.0 release assets used to build the
# AgriEdge-MMID benchmark described in Sec. 4.1 of the manuscript.
#
# Source: https://github.com/dunxiandu/AgriMultiSense/releases/tag/v1.0
#
# Usage:
#   bash scripts/download_dataset.sh [DEST_DIR]
#
# Requires: curl (or wget), and optionally GitHub CLI (gh) for large assets.

set -euo pipefail

DEST_DIR="${1:-data/AgriMultiSense_raw}"
REPO="dunxiandu/AgriMultiSense"
TAG="v1.0"

mkdir -p "${DEST_DIR}"
cd "${DEST_DIR}"

echo "Fetching release metadata for ${REPO}@${TAG} ..."
API_URL="https://api.github.com/repos/${REPO}/releases/tags/${TAG}"

if command -v gh >/dev/null 2>&1; then
  echo "Using GitHub CLI to download all release assets ..."
  gh release download "${TAG}" --repo "${REPO}" --dir .
else
  echo "GitHub CLI not found; falling back to curl + GitHub API asset listing."
  echo "(Install 'gh' for a more robust download of large binary assets.)"
  ASSET_URLS=$(curl -sSL "${API_URL}" | grep -o '"browser_download_url": *"[^"]*"' | sed -E 's/.*"(https[^"]+)"/\1/')
  if [ -z "${ASSET_URLS}" ]; then
    echo "ERROR: could not list release assets via the GitHub API."
    echo "Please download the assets manually from:"
    echo "  https://github.com/${REPO}/releases/tag/${TAG}"
    exit 1
  fi
  while IFS= read -r url; do
    fname=$(basename "${url}")
    echo "Downloading ${fname} ..."
    curl -sSL -o "${fname}" "${url}"
  done <<< "${ASSET_URLS}"
fi

echo "Extracting archives (if any) ..."
for f in *.zip; do
  [ -e "$f" ] || continue
  unzip -o -q "$f" -d .
done
for f in *.tar.gz *.tgz; do
  [ -e "$f" ] || continue
  tar -xzf "$f" -C .
done

echo "Done. Raw AgriMultiSense assets are in: ${DEST_DIR}"
echo "Next step: run scripts/build_manifest.py to produce AgriEdge-MMID"
echo "           JSONL manifests consumed by src/data/dataset.py."
