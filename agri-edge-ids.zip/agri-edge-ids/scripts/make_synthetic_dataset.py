#!/usr/bin/env python3
"""Generates a small synthetic dataset matching the AgriEdge-MMID manifest
schema (see src/data/dataset.py), so the full training / evaluation /
ablation pipeline can be run and unit-tested end-to-end without first
downloading the full raw AgriMultiSense release.

This is NOT a substitute for the real benchmark and will not reproduce the
paper's reported numbers -- it exists purely so reviewers and downstream
users can verify the code runs correctly. See scripts/download_dataset.sh
and scripts/build_manifest.py to construct the real AgriEdge-MMID manifests
from the released AgriMultiSense assets.

Usage:
    python scripts/make_synthetic_dataset.py --out data/synthetic \
        --num-sequences 4 --windows-per-sequence 20
"""
from __future__ import annotations

import argparse
import json
import os
import random

import numpy as np
from PIL import Image

MODALITIES = ["pir", "gate", "vibration", "acoustic", "temperature", "humidity", "illumination"]
MODALITY_DIMS = {
    "pir": 2, "gate": 2, "vibration": 4, "acoustic": 8,
    "temperature": 4, "humidity": 4, "illumination": 4,
}


def make_image(path: str, size=(640, 640), seed: int = 0) -> None:
    rng = np.random.default_rng(seed)
    arr = (rng.random((size[1], size[0], 3)) * 255).astype(np.uint8)
    Image.fromarray(arr).save(path)


def make_rois(rng: random.Random, num_rois: int) -> list:
    rois = []
    for _ in range(num_rois):
        cx, cy = rng.uniform(0.1, 0.9), rng.uniform(0.1, 0.9)
        w, h = rng.uniform(0.05, 0.3), rng.uniform(0.05, 0.3)
        rois.append(
            {
                "bbox_norm": [cx, cy, w, h],
                "detector_confidence": round(rng.uniform(0.4, 0.99), 3),
                "illumination_consistency": round(rng.uniform(0.3, 1.0), 3),
                "occlusion_ratio": round(rng.uniform(0.0, 0.5), 3),
                "blur_intensity": round(rng.uniform(0.0, 0.4), 3),
            }
        )
    return rois


def make_sensors(rng: random.Random, num_sensors: int, window_time: float) -> list:
    sensors = []
    for i in range(num_sensors):
        modality = rng.choice(MODALITIES)
        dim = MODALITY_DIMS[modality]
        sensors.append(
            {
                "sensor_id": f"{modality}_{i:02d}",
                "modality": modality,
                "value": [round(rng.uniform(-1, 1), 3) for _ in range(dim)],
                "position_xy": [round(rng.uniform(0, 100), 2), round(rng.uniform(0, 100), 2)],
                "timestamp": window_time + rng.uniform(0, 1.0),
                "last_valid_timestamp": window_time - rng.uniform(0, 3.0),
                "packet_reliability": round(rng.uniform(0.7, 1.0), 3),
                "signal_stability": round(rng.uniform(0.6, 1.0), 3),
                "missing_event_rate": round(rng.uniform(0.0, 0.2), 3),
                "is_available": rng.random() > 0.05,
            }
        )
    return sensors


def build_split(out_dir: str, split: str, num_sequences: int, windows_per_sequence: int, seed: int):
    rng = random.Random(seed)
    image_dir = os.path.join(out_dir, "images", split)
    os.makedirs(image_dir, exist_ok=True)
    manifest_path = os.path.join(out_dir, f"{split}.jsonl")

    with open(manifest_path, "w", encoding="utf-8") as f:
        for s in range(num_sequences):
            sequence_id = f"{split}_farm{s:02d}"
            intrusion_start = rng.randint(windows_per_sequence // 3, 2 * windows_per_sequence // 3)
            intrusion_len = rng.randint(2, 5)
            for w in range(windows_per_sequence):
                window_time = w * 10.0
                image_rel = f"{sequence_id}_{w:04d}.png"
                image_abs = os.path.join(image_dir, image_rel)
                make_image(image_abs, seed=hash((sequence_id, w)) % (2**31))

                label = int(intrusion_start <= w < intrusion_start + intrusion_len)
                num_rois = rng.randint(1, 3) if label else rng.randint(0, 2)
                num_sensors = rng.randint(3, 7)

                entry = {
                    "sequence_id": sequence_id,
                    "window_time": window_time,
                    "image_path": os.path.join("images", split, image_rel),
                    "rois": make_rois(rng, num_rois),
                    "sensors": make_sensors(rng, num_sensors, window_time),
                    "env_features": [
                        round(rng.uniform(10, 35), 2),   # temperature C
                        round(rng.uniform(30, 90), 2),   # humidity %
                        round(rng.uniform(0, 15), 2),    # rainfall mm/h
                        round(rng.uniform(990, 1025), 2),# pressure hPa
                        round(rng.uniform(0, 10), 2),    # wind m/s
                        round(rng.uniform(0, 1), 3),     # fog density index
                    ],
                    "env_position": [50.0, 50.0],
                    "label": label,
                }
                f.write(json.dumps(entry) + "\n")

    print(f"[{split}] wrote {num_sequences} sequences x {windows_per_sequence} windows -> {manifest_path}")


def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--out", default="data/synthetic", help="Output directory")
    ap.add_argument("--num-sequences", type=int, default=4, help="Sequences per split")
    ap.add_argument("--windows-per-sequence", type=int, default=20)
    ap.add_argument("--seed", type=int, default=0)
    args = ap.parse_args()

    os.makedirs(args.out, exist_ok=True)
    splits = {"train": args.num_sequences, "val": max(1, args.num_sequences // 2), "test": max(1, args.num_sequences // 2)}
    for split, n_seq in splits.items():
        build_split(args.out, split, n_seq, args.windows_per_sequence, seed=args.seed + hash(split) % 1000)

    print("Synthetic dataset ready at:", args.out)


if __name__ == "__main__":
    main()
