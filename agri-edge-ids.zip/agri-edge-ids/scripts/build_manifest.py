#!/usr/bin/env python3
"""Builds AgriEdge-MMID JSONL manifests (src/data/dataset.py schema) from
the raw assets downloaded via scripts/download_dataset.sh.

WHY A SEPARATE ADAPTER STEP?
The AgriMultiSense v1.0 release (github.com/dunxiandu/AgriMultiSense) ships
several independent asset groups -- RGB surveillance images, wildlife
monitoring images, thermal images, environmental records, acoustic event
streams, IoT sensor streams, edge-deployment events, and precomputed graph
structures -- whose exact internal file/folder naming can change between
dataset releases or mirrors. Rather than hard-coding brittle assumptions,
this script takes a small `--layout` JSON file describing where each raw
asset group lives, so the manifest builder keeps working across dataset
revisions. A template layout file is provided at
`configs/dataset_layout.example.json` -- copy it, point the paths at your
extracted `data/AgriMultiSense_raw/` directory, and adjust the glob
patterns / column names to match what you actually find on disk.

This keeps modeling code (src/models/) completely decoupled from any one
raw dataset layout: once you have a correct manifest, everything in
src/train.py, src/evaluate.py and src/ablation.py works unmodified.

Usage:
    python scripts/build_manifest.py \
        --layout configs/dataset_layout.example.json \
        --out data/AgriEdge-MMID
"""
from __future__ import annotations

import argparse
import glob
import json
import os
from collections import defaultdict

import pandas as pd


def load_layout(path: str) -> dict:
    with open(path, "r", encoding="utf-8") as f:
        return json.load(f)


def build_sensor_stream(layout: dict) -> pd.DataFrame:
    """Reads one or more IoT sensor CSV files (columns configurable via
    `layout['iot_sensor_columns']`) and returns a tidy DataFrame with
    columns: sensor_id, modality, value (JSON-encoded list), position_xy,
    timestamp, last_valid_timestamp, packet_reliability, signal_stability,
    missing_event_rate, is_available, sequence_id.
    """
    frames = []
    for csv_path in glob.glob(layout["iot_sensor_glob"]):
        df = pd.read_csv(csv_path)
        frames.append(df)
    if not frames:
        return pd.DataFrame()
    return pd.concat(frames, ignore_index=True)


def build_env_stream(layout: dict) -> pd.DataFrame:
    frames = []
    for csv_path in glob.glob(layout["env_glob"]):
        df = pd.read_csv(csv_path)
        frames.append(df)
    if not frames:
        return pd.DataFrame()
    return pd.concat(frames, ignore_index=True)


def assign_event_windows(timestamps: pd.Series, window_sec: float) -> pd.Series:
    return (timestamps // window_sec) * window_sec


def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--layout", required=True, help="Path to a dataset layout JSON file")
    ap.add_argument("--out", default="data/AgriEdge-MMID", help="Output manifest directory")
    ap.add_argument("--window-sec", type=float, default=10.0)
    ap.add_argument("--max-sync-offset-ms", type=float, default=50.0)
    args = ap.parse_args()

    layout = load_layout(args.layout)
    os.makedirs(args.out, exist_ok=True)

    print("Loading IoT sensor streams ...")
    sensor_df = build_sensor_stream(layout)
    print(f"  -> {len(sensor_df)} raw sensor rows")

    print("Loading environmental telemetry ...")
    env_df = build_env_stream(layout)
    print(f"  -> {len(env_df)} raw environmental records")

    if sensor_df.empty:
        print(
            "WARNING: no sensor rows found. Check `iot_sensor_glob` in your "
            "layout file against the actual extracted directory structure "
            "under data/AgriMultiSense_raw/."
        )

    # Bucket every raw observation into its 10-second event window and
    # sequence (e.g. per-farm-site recording session), then emit one
    # manifest line per (sequence_id, window_time). Image linkage and
    # per-window label assignment depend on the specific annotation files
    # shipped with the release; adjust `attach_image_and_label()` below to
    # match their exact column names once you have inspected the raw data.
    windows = defaultdict(lambda: {"rois": [], "sensors": [], "env_features": None})

    if not sensor_df.empty:
        sensor_df["window_time"] = assign_event_windows(sensor_df["timestamp"], args.window_sec)
        for _, row in sensor_df.iterrows():
            key = (row["sequence_id"], row["window_time"])
            windows[key]["sensors"].append(
                {
                    "sensor_id": row["sensor_id"],
                    "modality": row["modality"],
                    "value": json.loads(row["value"]) if isinstance(row["value"], str) else list(row["value"]),
                    "position_xy": [row["pos_x"], row["pos_y"]],
                    "timestamp": row["timestamp"],
                    "last_valid_timestamp": row.get("last_valid_timestamp", row["timestamp"]),
                    "packet_reliability": row.get("packet_reliability", 1.0),
                    "signal_stability": row.get("signal_stability", 1.0),
                    "missing_event_rate": row.get("missing_event_rate", 0.0),
                    "is_available": bool(row.get("is_available", True)),
                }
            )

    print(
        f"Assembled {len(windows)} candidate event windows from sensor data. "
        "NOTE: image ROI attachment and ground-truth label assignment must "
        "be completed by extending `attach_image_and_label()` for your "
        "specific extracted annotation format -- see the TODO markers below."
    )

    # TODO: attach_image_and_label(windows, layout, env_df)
    # This step should, for each (sequence_id, window_time) key:
    #   1. locate the corresponding RGB/thermal frame(s) and their
    #      per-image bounding-box annotations (COCO/VisDrone/UAVDT/iWildCam/
    #      FLIR style, depending on `layout['image_annotation_format']`);
    #   2. append the resulting ROI dicts to windows[key]['rois'];
    #   3. attach the matching environmental record from `env_df` (nearest
    #      timestamp within `args.max_sync_offset_ms`) to
    #      windows[key]['env_features'];
    #   4. assign the unified intrusion label (human / vehicle / wildlife /
    #      normal, collapsed to a binary 1/0 as used by the model) from the
    #      release's ground-truth annotation files.
    # Once implemented, write out train/val/test/field JSONL files using
    # the farm-independent 70/10/20 split strategy described in Sec. 4.1.

    manifest_path = os.path.join(args.out, "windows_partial.jsonl")
    with open(manifest_path, "w", encoding="utf-8") as f:
        for (sequence_id, window_time), payload in sorted(windows.items()):
            entry = {
                "sequence_id": sequence_id,
                "window_time": window_time,
                "image_path": None,   # filled in by attach_image_and_label()
                "rois": payload["rois"],
                "sensors": payload["sensors"],
                "env_features": payload["env_features"],
                "env_position": layout.get("default_env_position", [50.0, 50.0]),
                "label": None,        # filled in by attach_image_and_label()
            }
            f.write(json.dumps(entry) + "\n")

    print(f"Wrote partial manifest (sensor-only) to {manifest_path}.")
    print("Complete image/label attachment before using this for training;")
    print("src/data/dataset.py requires non-null 'image_path' and 'label'.")


if __name__ == "__main__":
    main()
