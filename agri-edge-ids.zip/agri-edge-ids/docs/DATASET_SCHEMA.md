# AgriEdge-MMID manifest schema

All code under `src/` consumes a **manifest-based** representation of the
dataset rather than reading raw AgriMultiSense files directly. This keeps
the model implementation decoupled from the exact folder layout of any
particular release of the raw data.

A manifest is a JSON-Lines file (one JSON object per line). Each line
describes exactly one **10-second multimodal event window**
(`event_window_sec` in `configs/default.yaml`, Sec. 4.1.1 of the paper).

```jsonc
{
  // Groups windows into an ordered monitoring session (e.g. one farm-day).
  // The temporal graph memory (Sec. 3.4.5) and confidence stabilizer
  // (Sec. 3.5) are threaded across windows that share a sequence_id, in
  // ascending window_time order.
  "sequence_id": "farm03_2024-11-02",

  // Seconds since the start of the sequence.
  "window_time": 1234.0,

  // Path to the representative RGB/thermal frame for this window,
  // relative to --image-root.
  "image_path": "images/farm03/000123.png",

  // Zero or more detected regions of interest in this frame.
  "rois": [
    {
      "bbox_norm": [0.52, 0.41, 0.18, 0.24],   // [cx, cy, w, h] in [0, 1]
      "detector_confidence": 0.92,              // c_i, Sec. 3.2
      "illumination_consistency": 0.80,         // l_i, Sec. 3.2
      "occlusion_ratio": 0.10,                  // o_i, Sec. 3.2
      "blur_intensity": 0.05                    // b_i, Sec. 3.2
    }
  ],

  // Zero or more IoT sensor readings synchronized to this window.
  "sensors": [
    {
      "sensor_id": "pir_04",
      "modality": "pir",                        // see src/models/iot.py
      "value": [1.0, 0.0],                       // raw reading vector
      "position_xy": [12.5, 8.0],                // meters, for spatial edges
      "timestamp": 1234.1,
      "last_valid_timestamp": 1230.0,
      "packet_reliability": 0.98,
      "signal_stability": 0.95,
      "missing_event_rate": 0.02,
      "is_available": true
    }
  ],

  // [temperature_C, humidity_pct, rainfall_mm_per_h, pressure_hPa,
  //  wind_m_s, fog_density_index] -- adjust EnvironmentEncoder's
  // input_dim in configs/default.yaml if you add/remove fields.
  "env_features": [24.5, 63.0, 0.0, 1013.2, 3.1, 0.05],
  "env_position": [50.0, 50.0],

  // Binary ground-truth label: 1 = intrusion, 0 = normal operation.
  "label": 1
}
```

## Known IoT modalities and raw feature dimensionality

See `DEFAULT_MODALITY_INPUT_DIMS` in `src/models/iot.py`:

| modality      | raw `value` length | notes                                   |
|---------------|--------------------:|------------------------------------------|
| `pir`         | 2                    | binary event-driven                       |
| `gate`        | 2                    | binary event-driven                       |
| `vibration`   | 4                    | short statistical aggregate               |
| `acoustic`    | 8                    | short statistical / spectral aggregate    |
| `temperature` | 4                    | continuous telemetry aggregate            |
| `humidity`    | 4                    | continuous telemetry aggregate            |
| `illumination`| 4                    | continuous telemetry aggregate            |

If your raw acoustic/telemetry pipeline produces a different feature
length, update `DEFAULT_MODALITY_INPUT_DIMS` (or pass a custom
`modality_input_dims` dict into `IoTSensorEncoder` / `AgriEdgeIDS`)
accordingly.

## Producing manifests

* **Synthetic (for smoke-testing only):**
  `python scripts/make_synthetic_dataset.py --out data/synthetic`
* **Real AgriEdge-MMID, built from the AgriMultiSense v1.0 release:**
  1. `bash scripts/download_dataset.sh data/AgriMultiSense_raw`
  2. Copy `configs/dataset_layout.example.json`, edit the glob patterns to
     match what you find under `data/AgriMultiSense_raw/`.
  3. `python scripts/build_manifest.py --layout <your_layout>.json --out data/AgriEdge-MMID`
     This script currently assembles the IoT/environmental side of each
     window automatically; image/label attachment must be completed by
     extending `attach_image_and_label()` (clearly marked with `TODO` in
     the script) once you have inspected the exact annotation format
     shipped with the release assets on your machine.
