"""Lightweight shape / smoke tests for every module in src/models.

Run with:  pytest -q
These do not require the real AgriEdge-MMID dataset -- they construct
minimal synthetic tensors directly in-memory.
"""
import torch

from src.models.decision import (
    AdaptiveAlertGenerator,
    IntrusionDecisionHead,
    TemporalConfidenceStabilizer,
)
from src.models.gat import HeteroGAT
from src.models.graph_build import assemble_graph
from src.models.iot import IoTSensorEncoder, SensorObservation
from src.models.model import AgriEdgeIDS, EventWindow
from src.models.readout import HierarchicalReliabilityReadout
from src.models.visual import ROIObservation, ReliabilityAwareVisualEncoder


def make_roi(cx=0.5, cy=0.5):
    return ROIObservation(
        patch=torch.rand(3, 64, 64),
        bbox_norm=torch.tensor([cx, cy, 0.2, 0.2]),
        detector_confidence=0.9,
        illumination_consistency=0.8,
        occlusion_ratio=0.1,
        blur_intensity=0.05,
    )


def make_sensor(sensor_id="pir_00", modality="pir"):
    from src.models.iot import DEFAULT_MODALITY_INPUT_DIMS

    dim = DEFAULT_MODALITY_INPUT_DIMS[modality]
    return SensorObservation(
        sensor_id=sensor_id,
        modality=modality,
        value=[0.1] * dim,
        position_xy=[10.0, 10.0],
        timestamp=5.0,
        last_valid_timestamp=4.0,
        packet_reliability=0.95,
        signal_stability=0.9,
        missing_event_rate=0.05,
        is_available=True,
    )


def test_visual_encoder_shapes():
    enc = ReliabilityAwareVisualEncoder(embedding_dim=32, pretrained=False)
    frame = torch.rand(3, 64, 64)
    out = enc(frame, [make_roi(), make_roi(0.3, 0.3)])
    assert out["z"].shape[1] == 32 + 4 + 1
    assert out["reliability"].shape[0] == out["z"].shape[0]


def test_visual_encoder_empty_rois():
    enc = ReliabilityAwareVisualEncoder(embedding_dim=32, pretrained=False)
    frame = torch.rand(3, 64, 64)
    out = enc(frame, [])
    assert out["z"].shape == (0, 32 + 4 + 1)


def test_iot_encoder_shapes():
    enc = IoTSensorEncoder(embedding_dim=32)
    device = torch.device("cpu")
    obs = [make_sensor(), make_sensor("gate_00", "gate")]
    out = enc(obs, current_time=5.0, device=device)
    assert out["s_hat"].shape == (2, 32 + 2)
    assert out["positions"].shape == (2, 2)


def test_graph_assembly_and_gat():
    d = 16
    visual_z = torch.rand(2, d)
    visual_pos = torch.rand(2, 2) * 100
    visual_ts = torch.zeros(2)
    visual_rel = torch.tensor([0.8, 0.6])

    sensor_s = torch.rand(3, d)
    sensor_pos = torch.rand(3, 2) * 100
    sensor_ts = torch.zeros(3)
    sensor_rel = torch.tensor([0.9, 0.7, 0.5])
    sensor_avail = torch.tensor([1.0, 1.0, 0.0])

    env_embedding = torch.rand(d)
    env_pos = torch.tensor([50.0, 50.0])

    graph = assemble_graph(
        visual_z, visual_pos, visual_ts, visual_rel,
        sensor_s, sensor_pos, sensor_ts, sensor_rel, sensor_avail,
        env_embedding, env_pos,
        k_neighbors=3,
    )
    assert graph.x.shape[0] == 6  # 2 visual + 3 sensor + 1 env

    gat = HeteroGAT(in_dim=d, hidden_dim=d, num_layers=2, heads=4, dropout=0.0)
    h = gat(graph.x, graph.edge_index, graph.edge_weight, graph.availability)
    assert h.shape == (6, d)


def test_readout_and_decision():
    d = 16
    h = torch.rand(5, d)
    node_type = torch.tensor([0, 0, 1, 1, 2])
    reliability = torch.rand(5)
    context = torch.rand(d)

    readout = HierarchicalReliabilityReadout(hidden_dim=d, context_dim=d)
    g_hat, mem = readout(h, node_type, reliability, context, prev_memory=None)
    assert g_hat.shape == (d,)
    assert mem.shape == (d,)

    head = IntrusionDecisionHead(in_dim=d, hidden_dim=d)
    logit = head(g_hat.unsqueeze(0)).squeeze()
    assert logit.dim() == 0

    stabilizer = TemporalConfidenceStabilizer()
    p_t = torch.sigmoid(logit)
    p_hat = stabilizer(p_t.unsqueeze(0), None).squeeze(0)
    assert 0.0 <= p_hat.item() <= 1.0

    alert_gen = AdaptiveAlertGenerator()
    decision = alert_gen.step(p_hat.item(), mean_reliability=0.8)
    assert "alarm_transmitted" in decision


def test_full_model_forward_event():
    model = AgriEdgeIDS(embedding_dim=16, gat_layers=2, attention_heads=4, pretrained_visual_backbone=False)
    from src.models.model import ModelState

    event = EventWindow(
        frame=torch.rand(3, 64, 64),
        rois=[make_roi()],
        sensor_observations=[make_sensor()],
        env_features=torch.rand(6),
        env_position=torch.tensor([50.0, 50.0]),
        window_time=0.0,
        label=1,
    )
    state = ModelState()
    out = model.forward_event(event, state)
    assert out["logit"].dim() == 0
    assert 0.0 <= out["p_hat_t"].item() <= 1.0

    # a second window should reuse and update the carried state
    event2 = EventWindow(
        frame=torch.rand(3, 64, 64),
        rois=[],
        sensor_observations=[make_sensor("gate_01", "gate")],
        env_features=torch.rand(6),
        env_position=torch.tensor([50.0, 50.0]),
        window_time=10.0,
        label=0,
    )
    out2 = model.forward_event(event2, state)
    assert out2["logit"].dim() == 0
